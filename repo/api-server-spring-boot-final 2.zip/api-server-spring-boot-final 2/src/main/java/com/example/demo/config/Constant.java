package com.example.demo.config;

public class Constant {
}

